package com.backendtest.model;

public enum TaskType {
    STANDARD_USER_TASK,
    COMPANY_ADMIN_TASK
}
